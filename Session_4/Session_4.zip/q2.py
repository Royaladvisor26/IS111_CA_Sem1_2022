# If you are getting a "No such file or directory" error message, right click on the text file and select "Copy Path", and replace 'q1.txt' with that file path.
# In lab test, DO NOT use your copied path, just revert back to q2.txt

DECRYPT_DICT = {'a': 'b', 'b': 'c', 'c': 'j', 'd': 'k', 
                'e': 'l', 'f': 'a', 'g': 'm', 'h': 'n', 
                'i': 'o', 'j': 'p', 'k': 'q', 'l': 'r', 
                'm': 's', 'n': 't', 'o': 'u', 'p': 'v', 
                'q': 'w', 'r': 'x', 's': 'y', 't': 'z', 
                'u': 'd', 'v': 'e', 'w': 'f', 'x': 'g', 
                'y': 'h', 'z': 'i'}

# YOUR CODE GOES HERE