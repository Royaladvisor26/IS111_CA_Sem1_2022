def encode(string):
    # Your code here
    return string