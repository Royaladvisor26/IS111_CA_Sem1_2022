def is_magic_square():
    
    # YOUR CODE GOES HERE

    return 

