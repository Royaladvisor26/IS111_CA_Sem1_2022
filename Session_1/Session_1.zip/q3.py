def holidaybush(n):
    # YOUR CODE GOES HERE
    
    pass

# DO NOT MODIFY THE BELOW TEST CASES
print('----Test Case 1----')
holidaybush(5)